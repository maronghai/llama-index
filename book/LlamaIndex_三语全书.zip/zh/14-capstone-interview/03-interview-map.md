# 14.03 重点难点地图与面试表达

[返回全书目录 / Contents](../00-contents.md)

学习优先级分三层：必须掌握 Document/Node、显式模型配置、数据解析、切块、向量检索、引用与评估；进阶掌握混合检索、重排、父块、路由和存储更新；按任务选学属性图、多 Agent 和多模态。先把单链路做可靠，再增加可证明有收益的复杂度。

面试问题一：如何优化召回？先确认标签与失败分布，再检查解析、模型、切块、混合候选和重排；每步报告代价。问题二：如何防幻觉？分开处理数据缺失、检索不足与生成越界，增加证据核验与拒答。问题三：如何做增量？稳定 ID、内容哈希、检查点、删除传播和对账。

问题四：如何上线？说明独立构建、版本发布、权限、限流、观测、评估门禁与回滚。问题五：如何选数据库？按过滤、规模、运维、恢复、租户和团队能力，不只看排行榜。问题六：如何证明效果？展示固定基线、开发/测试分离、配对结果、错误案例和真实成本。

表达项目时使用“目标—约束—基线—失败—选择—验证—结果”的顺序。没有实测结果就直说目前是设计或实验阶段。技术术语只有在能解释为什么需要它、如何失败和怎样验证时才有价值。

## 重点与难点

重点：先掌握可复现基本链路，再按失败选择高级架构。难点：把概念知识转成可验证的工程判断。

## 面试考点与参考回答

问：LlamaIndex 的价值在哪里？答：提供连接数据、节点、检索、合成、工具与工作流的统一抽象及集成，减少重复编排；仍需开发者负责业务语义与生产边界。

## 项目中的坑与处置

坑：背 API 名称却无法解释取舍。处置：每个概念准备一个失败案例、一个实验和一个不适用场景。

## 动手实验与验收

用五分钟讲完整项目，再回答“预算减半”“必须离线”“权限实时撤销”三种追问。验收：方案随约束变化，且不虚构成绩。

## 代码实现补充：用证据组织项目面试回答

依赖：Python 3.10+；仅使用 Python 标准库。

运行方式：将下面完整代码保存为独立 `.py` 文件，在独立进程执行 `python 文件名.py`；无需 API Key，不调用付费模型服务。成功时断言通过并打印结果。

```python
from dataclasses import dataclass

@dataclass
class Experiment:
    name: str
    recall_before: float
    recall_after: float
    p95_before_ms: int
    p95_after_ms: int
    samples: int

    def report(self):
        if self.samples < 1:
            raise ValueError("sample count is required")
        return {
            "change": self.name,
            "recall_delta_pp": round(100 * (self.recall_after - self.recall_before), 2),
            "latency_delta_ms": self.p95_after_ms - self.p95_before_ms,
            "samples": self.samples,
        }

experiment = Experiment("hybrid retrieval", 0.72, 0.84, 600, 750, 200)
report = experiment.report()
assert report["recall_delta_pp"] == 12.0 and report["latency_delta_ms"] == 150
print(report)
print("Explain: symptom -> hypothesis -> controlled change -> evidence -> tradeoff -> rollback")
```

### 实现说明、验收与项目边界

示例中的数字是假设数据，不可作为个人项目成绩。面试时说明标签来源、样本量、失败切片、延迟代价和对照条件；12 个百分点不等于相对增长 12%。项目练习：用自己评测产物替换输入，并解释置信区间与下一步实验。
