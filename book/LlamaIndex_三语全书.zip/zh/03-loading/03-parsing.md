# 03.03 PDF、表格、图像与解析质量

[返回全书目录 / Contents](../00-contents.md)

复杂文档的关键是保留结构，而不是尽可能多地抽出字符。两栏 PDF 需要正确阅读顺序，表格需要保留列标题与单位，扫描页需要 OCR，图表需要能回溯到原页的描述。托管解析服务与本地解析各有成本、隐私、延迟和版面能力边界，应通过样本评测选择。

例如“销售额 120”如果丢掉“万元”和“2025 年”就会产生错误答案。把表头、行键、时间、单位和脚注一起保存，必要时把表格行转成带列名的文本。对金额计算，优先从结构化数据执行确定性计算，再由模型解释，而不是让模型心算。

质量检查应从业务问题反推：条款是否完整、表格单元格是否对应、页码能否定位、图片中是否含必要证据。多模态检索与“把图片描述转成文本检索”不是同一种方案；前者需要兼容的图文表示，后者会受描述遗漏影响。

## 重点与难点

重点：版面、单位与出处。难点：跨页表格、嵌套表头和图表描述中的信息损失无法靠扩大 top-k 修复。

## 面试考点与参考回答

问：PDF RAG 为什么难？答：PDF 保存视觉布局而不保证逻辑结构；必须把阅读顺序、表格、OCR 和来源映射纳入评估。

## 项目中的坑与处置

坑：把模型生成的表格解释当成原始事实。处置：区分原文、结构化提取和推导描述，并给每种结果记录生成方式和置信边界。

## 动手实验与验收

选取含两栏、跨页表格、扫描页的三份样本，人工核对十个事实。验收：每个事实可定位原页、单位不丢失，失败样本有明确处理策略。

## 代码实现补充：解析结果质量门禁

依赖：Python 3.10+；仅使用 Python 标准库。

运行方式：将下面完整代码保存为独立 `.py` 文件，在独立进程执行 `python 文件名.py`；无需 API Key，不调用付费模型服务。成功时断言通过并打印结果。

```python
from dataclasses import dataclass

@dataclass
class ParsedPage:
    source: str
    page: int
    text: str
    table_rows: list[list[str]]

def validate(page):
    errors = []
    if not page.source or page.page < 1:
        errors.append("missing provenance")
    if len(page.text.strip()) < 20:
        errors.append("sparse text: OCR review required")
    if "\ufffd" in page.text:
        errors.append("replacement character")
    widths = {len(row) for row in page.table_rows}
    if len(widths) > 1:
        errors.append("ragged table")
    return errors

good = ParsedPage("policy.pdf", 1, "Hotel allowance: CNY 500 per night.",
                  [["city", "limit"], ["Shanghai", "500"]])
bad = ParsedPage("scan.pdf", 2, "\ufffd", [["city", "limit"], ["500"]])
assert validate(good) == []
assert len(validate(bad)) == 3
print(validate(bad))
```

### 实现说明、验收与项目边界

输入是解析服务已经返回的结构化记录，不在此代码中读取 PDF 或执行 OCR。稀疏正文、乱码、列宽不一致进入人工复核队列。字符数阈值不能证明表格语义正确，还需抽样核对跨页表头、单位、负号与脚注。
